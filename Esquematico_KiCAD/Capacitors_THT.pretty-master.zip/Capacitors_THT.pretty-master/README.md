# Capacitors_THT.pretty
Through hole capacitor footprints

## Note

This repository is now marked as read-only and will no longer accept pull requests. To contribute, refer to the new footprints library at https://github.com/kicad/kicad-footprints
