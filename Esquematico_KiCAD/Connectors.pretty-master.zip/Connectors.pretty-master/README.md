# Connectors.pretty

Assorted connector footprints

This repository is now deprecated - please refer to the new footprint libraries at https://github.com/kicad/kicad-footprints
